namespace Programming_Patterns.Factory.Models.Enums
{
    public enum Rarity
    {
        Common,
        Uncommon,
        Rare,
        Special,
        Legendary,
        Unique,
    }
}
