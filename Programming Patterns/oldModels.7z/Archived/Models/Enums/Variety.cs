namespace Programming_Patterns.Factory.Models.Enums
{
    public enum Variety
    {
        Fan,
        Character,
        Soldier,
        Hero,
        Villain,
        Supernatural,
    }
}
