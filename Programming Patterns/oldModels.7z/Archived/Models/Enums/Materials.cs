namespace Programming_Patterns.Factory.Models.Enums
{
    public enum Materials
    {
        Wood,
        Plastic,
        Metal,
        Fabric,
        Cartboard
    }
}
