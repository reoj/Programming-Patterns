﻿using Programming_Patterns.Factory.Models.Abstact;
using Programming_Patterns.Factory.Models.Enums;

namespace Programming_Patterns.Factory.Models
{
    internal class BarberaDoll : ToyDoll
    {
        public Rarity BarberaRarity { get; set; }
        public int BarberaSeason { get; set; }
        public Variety BarberaVariety { get; set; }

        public BarberaDoll()
        {
            base.Amount = 1;
            BarberaRarity = SetRarity();
            BarberaSeason = new Random().Next(0, 20);
            BarberaVariety = SetVariety();
        }

        private static Rarity SetRarity()
        {
            const int maxVal = (int)Rarity.Unique;
            var rndSource = new Random();
            var rndValue = rndSource.Next(0, maxVal);
            return (Rarity)rndValue;
        }
        private static Variety SetVariety()
        {
            const int maxVal = (int)Variety.Supernatural;
            var rndSource = new Random();
            var rndValue = rndSource.Next(0, maxVal);
            return (Variety)rndValue;
        }

        public override string ToString()
        {
            string output = base.ToString();
            output += $"B.Type: {BarberaVariety}\n";
            output += $"Certified B.Rarity: {BarberaRarity}\n";
            output += $"B.Season: {BarberaSeason} \n";

            return output;
        }
    }
}
