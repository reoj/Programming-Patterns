﻿using Programming_Patterns.Factory.Models.Abstact;

namespace Programming_Patterns.Factory.Models
{
    internal class RideableCar : ToyCar
    {
        public int Capacity { get; set; }

        public RideableCar()
        {
            base.Amount = 1;
            base.ComercialName = "RideCar";
            base.Recomendation = "For 3 - 6 years of age";

            base.Materials = Enums.Materials.Plastic;
            base.MainColor = "Pink";
            Capacity = 4;
        }
    }
}
