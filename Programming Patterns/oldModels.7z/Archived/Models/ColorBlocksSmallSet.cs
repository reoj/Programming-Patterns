﻿using Programming_Patterns.Factory.Models.Abstact;
using Programming_Patterns.Factory.Models.Enums;

namespace Programming_Patterns.Factory.Models
{
    public class ColorBlocksSmallSet : ToyBlockSet
    {
        public float MandatedBoxVolume { get; set; }

        public ColorBlocksSmallSet()
        {
            ComercialName = "Mini Blocks";
            Amount = 50;
            Materials = Materials.Plastic;

            WidthInCM = 1.3f;
            HeightInCM = 1.3f;
            DepthInCM = 1.3f;

            colors = new() { "red", "green", "blue", "white", "black" };
            Recomendation = "For children 5 - 10 years of age";
            MandatedBoxVolume = 45000.0f;
        }

        public override string ToString()
        {
            string output = base.ToString();

            output += $"Box Dimensions: {MandatedBoxVolume} cm3\n";
            output += $"Recommended: {Recomendation} \n";
            output += "Intended for compact building\n";

            return output;
        }
    }
}
