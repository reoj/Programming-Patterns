﻿using Programming_Patterns.Factory.Models.Abstact;
using Programming_Patterns.Factory.Models.Enums;

namespace Programming_Patterns.Factory.Models
{
    internal class ColorBlocksBigSet : ToyBlockSet
    {
        public bool IsSchalable { get; set; }

        public ColorBlocksBigSet()
        {
            ComercialName = "Big Blocks";
            Amount = 10;
            Materials = Materials.Plastic;

            WidthInCM = 10.0f;
            HeightInCM = 10.0f;
            DepthInCM = 10.0f;

            colors = new() { "yellow", "red", "green", "blue", "white" };
            Recomendation = "For children 0 - 3 years of age";
            IsSchalable = false;
        }

        public float CalculateTotalVolume => 5 * DepthInCM * 2 * WidthInCM * HeightInCM;

        public override string ToString()
        {
            string output = base.ToString();

            output += $"Box Dimensions: {CalculateTotalVolume} cm3\n";
            output += $"Recommended: {Recomendation} \n";
            output += $"Schalability is safe for children? {IsSchalable}\n";

            return output;
        }
    }
}
