﻿namespace Programming_Patterns.Factory.Models.Abstact
{
    public abstract class ToyBlockSet : Toy
    {
        public float WidthInCM { get; set; }
        public float HeightInCM { get; set; }
        public float DepthInCM { get; set; }
        public List<string> colors = new();

        public string GetColorsAsString()
        {
            string output = "";
            colors.ForEach(color => output += color + ", ");
            return output;
        }

        public override string ToString()
        {
            string output = base.ToString();
            output += $"Dimensions (per piece): {WidthInCM}x{HeightInCM}x{DepthInCM} cm.\n";
            output += $"Colors: {GetColorsAsString()}" + '\n';
            return output;
        }
    }
}
