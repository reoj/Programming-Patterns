﻿namespace Programming_Patterns.Factory.Models.Abstact
{
    internal class ToyCar: Toy
    {
        public string MainColor { get; set; }
        public ToyCar()
        {

        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
