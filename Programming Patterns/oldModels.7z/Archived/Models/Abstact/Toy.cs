﻿using Programming_Patterns.Factory.Models.Enums;

namespace Programming_Patterns.Factory.Models.Abstact
{
    public abstract class Toy
    {
        public Guid Id { get; set; }
        public string ComercialName { get; set; }
        public int Amount { get; set; }
        public static int Stock { get; set; }
        public Materials Materials { get; set; }
        public string Recomendation { get; set; }

        internal Toy()
        {
            Id = Guid.NewGuid();
            ComercialName = String.Empty;
        }

        public override string ToString()
        {
            string output = $"Toy Name: {ComercialName}\n";
            output += $"Identifier: {Id} \n";
            output += $"In Inventory: {Stock}\n";
            output += $"Contains: {Amount} pieces" + '\n';
            output += $"Materials: {Materials}\n";
            return output;
        }
    }
}
