﻿namespace Programming_Patterns.Factory.Models.Abstact
{
    public class ToyDoll: Toy
    {
        public ToyDoll() { }
        public override string ToString()
        {
            return base.ToString();
        }
    }
    
}
