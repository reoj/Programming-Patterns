﻿using Programming_Patterns.Factory.Models.Abstact;

namespace Programming_Patterns.Factory.Models
{
    public class CowboyDoll : ToyDoll
    {
        public CowboyDoll() { }
    }
}
