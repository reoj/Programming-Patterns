﻿using Programming_Patterns.Factory.Models.Abstact;

namespace Programming_Patterns.Factory.Models
{
    internal class RollableCar : ToyCar
    {
        public int Axis;

        public RollableCar()
        {
        }
    }
}
